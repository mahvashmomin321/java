package com.capgemini.demo.exception;

public class NegativeNumberException extends Exception {

	public NegativeNumberException(String message) {
		super(message);
		
	}
	
}
