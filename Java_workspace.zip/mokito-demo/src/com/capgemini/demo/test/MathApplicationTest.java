package com.capgemini.demo.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.capgemini.demo.MathApplication;
import com.capgemini.demo.exception.NegativeNumberException;
import com.capgemini.demo.service.CalculatorService;

public class MathApplicationTest {

	@Mock
	private CalculatorService service;

	@InjectMocks
	MathApplication application = new MathApplication(service);

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testAddtitionWithTwoPositiveInteger() {
		when(service.addition(6, 4)).thenReturn(10);
		assertEquals(10, application.perfromAddition(6, 4));
	}

	@Test
	public void testAdditionWithOneNegativeInteger() {
		when(service.addition(8, -2)).thenReturn(6);
		assertEquals(6, application.perfromAddition(8, -2));
	}

	@Test
	public void testAdditionWithTwoNegativeInteger() {
		when(service.addition(-8, -2)).thenReturn(-10);
		assertEquals(-10, application.perfromAddition(-8, -2));
	}

	@Test
	public void testSubstractionWithTwoPositiveInteger() {
		when(service.subtraction(10, 5)).thenReturn(5);
		assertEquals(5, application.performSubtraction(10, 5));
	}

	@Test
	public void testSubstractionWithOneNegativeInteger() {
		when(service.subtraction(10, -5)).thenReturn(15);
		assertEquals(15, application.performSubtraction(10, -5));
	}

	@Test
	public void testSubstractionWithTwoNegativeInteger() {
		when(service.subtraction(-10, -5)).thenReturn(-5);
		assertEquals(-5, application.performSubtraction(-10, -5));
	}

	@Test
	public void testMultiplicationWithTwoPositiveInteger() {
		when(service.multiplication(10, 5)).thenReturn(50);
		assertEquals(50, application.performMultiplication(10, 5));
	}

	@Test
	public void testMultiplicationWithOneNegativeInteger() {
		when(service.multiplication(10, -5)).thenReturn(-50);
		assertEquals(-50, application.performMultiplication(10, -5));
	}

	@Test
	public void testMultiplicationWithTwoNegativeInteger() {
		when(service.multiplication(-10, -5)).thenReturn(50);
		assertEquals(50, application.performMultiplication(-10, -5));
	}

	@Test
	public void testDivisionWithTwoPositiveInteger() {
		when(service.division(12, 6)).thenReturn(2);
		assertEquals(2, application.performDivision(12, 6));
	}

	@Test
	public void testDivisionWithTwoNegativeInteger() {
		when(service.division(-12, -6)).thenReturn(2);
		assertEquals(2, application.performDivision(-12, -6));
	}

	@Test
	public void testDivisionWithOneNegativeInteger() {
		when(service.division(12, -6)).thenReturn(-2);
		assertEquals(-2, application.performDivision(12, -6));
	}
	
	@Test(expected=ArithmeticException.class)
	public void testDivisionWithZero() {
		doThrow(new ArithmeticException("Divided by Zero")).when(service).division(10, 0);
		application.performDivision(10, 0);
	}
	
	
	@Test
	public void findSquareOfPositiveInteger() {
		when(service.square(10)).thenReturn(100L);
		assertEquals(100, application.findSquare(10));
	}
	
	@Test
	public void findSquareOfNegativeInteger() {
		when(service.square(-10)).thenReturn(100L);
		assertEquals(100, application.findSquare(-10));
	}
	
	@Test
	public void findFactorialOfPositiveInteger() throws NegativeNumberException {
		when(service.factorial(5)).thenReturn(120L);
		assertEquals(120, application.findFactorial(5));
	}
	
	@Test(expected=NegativeNumberException.class)
	public void findFactorialOfNegativeInteger() throws NegativeNumberException {
		doThrow(new NegativeNumberException("No Negative Number")).when(service).factorial(-5);
		application.findFactorial(-5);
		
	}
	
}
