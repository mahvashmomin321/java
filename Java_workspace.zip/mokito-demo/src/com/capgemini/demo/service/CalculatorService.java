package com.capgemini.demo.service;

import com.capgemini.demo.exception.NegativeNumberException;

public interface CalculatorService {

	public int addition(int number1,int number);
	public int subtraction(int number1,int number);
	public int multiplication(int number1,int number);
	public int division(int number1,int number);
	public long factorial(int number) throws NegativeNumberException;
	public long square(int number);
}
