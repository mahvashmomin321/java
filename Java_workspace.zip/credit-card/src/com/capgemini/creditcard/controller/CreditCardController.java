package com.capgemini.creditcard.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns= {"*.do"},loadOnStartup=1)
public class CreditCardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public CreditCardController() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String path= request.getServletPath();
		if(path.equals("/card.do")) {
			long cardNumber=Long.parseLong(request.getParameter("card_number"));
			String cardName=request.getParameter("customer_name");
			long cardLimit= Long.parseLong(request.getParameter("credit_limit"));
			RequestDispatcher dispatcher= request.getRequestDispatcher("creditcard.jsp");
			request.setAttribute("number", cardNumber);
			request.setAttribute("name", cardName);
			request.setAttribute("limit", cardLimit);
			dispatcher.forward(request, response);
		}
	}

}
