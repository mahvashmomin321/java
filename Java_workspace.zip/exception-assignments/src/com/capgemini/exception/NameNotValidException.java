package com.capgemini.exception;

public class NameNotValidException extends Exception {

	public NameNotValidException(String message) {
		super(message);
		
	}
	
}
