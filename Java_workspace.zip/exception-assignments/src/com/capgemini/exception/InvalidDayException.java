package com.capgemini.exception;

public class InvalidDayException extends Exception {

	public InvalidDayException(String message) {
		super(message);
		
	}

	
}
