package com.capgemini.exception;

public class DebitLimitExceeded extends Exception {

	public DebitLimitExceeded(String message) {
		super(message);

	}

}
