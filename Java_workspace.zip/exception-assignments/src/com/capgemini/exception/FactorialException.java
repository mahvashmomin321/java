package com.capgemini.exception;

public class FactorialException extends Exception {

	public FactorialException(String message) {
		super(message);
	
	}

	
}
