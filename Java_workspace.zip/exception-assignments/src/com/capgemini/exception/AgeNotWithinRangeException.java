package com.capgemini.exception;

public class AgeNotWithinRangeException extends Exception {

	public AgeNotWithinRangeException(String message) {
		super(message);
		
	}
	
}
