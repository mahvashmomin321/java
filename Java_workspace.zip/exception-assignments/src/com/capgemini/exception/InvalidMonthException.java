package com.capgemini.exception;

public class InvalidMonthException extends Exception {

	public InvalidMonthException(String message) {
		super(message);
	}
	
}
