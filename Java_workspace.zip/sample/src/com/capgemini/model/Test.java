package com.capgemini.model;

public class Test {
	public static void main(String[] args) {
		int[] array = {1, 2, 3, 4, 5};
		int x;
        for (int i = 0; i < array.length; i++) {
        	x= array[i];
			System.out.println(x);
		}
	}
}
