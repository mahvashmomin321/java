package com.capgemini.model;

public class GarbageTest {
	 public static void main(String[] args) 
	    { 
	       GarbageTest t1= new GarbageTest();
	       GarbageTest t2= new GarbageTest();
	  
	        t1=null;
	        t2=null;
	        System.gc(); 
	        System.out.println("Main Completes"); 
	    } 
	  
	  
	   @Override
	protected void finalize() throws Throwable {
		   System.out.println("finalize method overriden"); 
	}
}
