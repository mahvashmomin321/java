package com.capgemini.model;

public class Test {
	
	@Override
	protected void finalize() throws Throwable {
		System.out.println("Garbage collector called"); 
        System.out.println("Object garbage collected : " + this); 
	}
}
