package com.capgemini.lowbalance.exception;

public class LowBalanceException extends Exception {

	public LowBalanceException(String message) {
		super(message);
		
	}
	
}
