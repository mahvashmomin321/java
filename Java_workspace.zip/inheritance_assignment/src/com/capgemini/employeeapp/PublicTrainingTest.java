package com.capgemini.employeeapp;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.capgemini.employeeapp.model.PublicTraining;
import com.capgemini.employeeapp.model.Training;

public class PublicTrainingTest {

	@Test
	public void testOrderValue() {
		Training training= new PublicTraining(101,"Maths",2000,20);
		assertEquals(40000, training.getOrderValue(), 0.2);

	}
	

}
