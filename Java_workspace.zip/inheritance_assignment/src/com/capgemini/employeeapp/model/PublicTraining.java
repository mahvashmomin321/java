package com.capgemini.employeeapp.model;

public class PublicTraining extends Training {

	private int participants;

	public PublicTraining() {
		super();
	}

	public PublicTraining(int id, String subject, double fees, int participants) {
		super(id, subject, fees);
		this.participants = participants;
	}

	@Override
	public double getOrderValue() {
		return participants * getFees();
	}

	public int getParticipants() {
		return participants;
	}

	public void setParticipants(int participants) {
		this.participants = participants;
	}

}
