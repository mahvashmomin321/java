import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.capgemini.employeeapp.model.CorporateTraining;
import com.capgemini.employeeapp.model.Training;

public class CorporateTrainingTest {

	@Test
	public void testOrderValue() {
		Training training = new CorporateTraining(202, "JAVA", 10000, 20);
		assertEquals(200000, training.getOrderValue(),0.2);
	}
	
}
