package com.capgemini.banapp.exception;

public class LowBalanceException extends Exception {

	public LowBalanceException(String message) {
		super(message);
	
	}

	
}
